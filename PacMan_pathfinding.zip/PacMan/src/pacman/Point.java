/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pacman;

import java.util.ArrayList;

/**
 *
 * @author M
 */
public class Point {
    
    public int x;
    public int y;
    
    public int val;
    
    public boolean active=true;
    
    Point(int x,int y,int val)
    {
    this.x=x;
    this.y=y;
    this.val=val;
    }
}
