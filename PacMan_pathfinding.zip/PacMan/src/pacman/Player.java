/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pacman;


public class Player {

/*
int pos_x=16,pos_y=16;
int x=1,y=1;
*/

int pos_x=16*14,pos_y=16*17;
int x=1*14,y=1*17;

public int current_frame=0;
public int l=-1;

public int move_dir=4;
public int next_move_dir=4;

boolean able_up=false;
boolean able_down=false;
boolean able_left=false;
boolean able_right=false;

int dist_mov=1;

public int[][] collision_map=new int[31][28];

Player()
{



            collision_map =new int[][]                                  {{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}
									,{1,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1}
									,{1,0,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,0,1}
									,{1,0,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,0,1}
									,{1,0,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,0,1}
									,{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1}
									,{1,0,1,1,1,1,0,1,1,0,1,1,1,1,1,1,1,1,0,1,1,0,1,1,1,1,0,1}
									,{1,0,1,1,1,1,0,1,1,0,1,1,1,1,1,1,1,1,0,1,1,0,1,1,1,1,0,1}
									,{1,0,0,0,0,0,0,1,1,0,0,0,0,1,1,0,0,0,0,1,1,0,0,0,0,0,0,1}
									,{1,1,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,1,1}
									,{1,1,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,1,0}
									,{1,1,1,1,1,1,0,1,1,0,0,0,0,0,0,0,0,0,0,1,1,0,1,1,1,1,1,0}
									,{1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0}
									,{1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1}
									,{0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0}
									,{1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1}
									,{1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0}
									,{1,1,1,1,1,1,0,1,1,0,0,0,0,0,0,0,0,0,0,1,1,0,1,1,1,1,1,0}
									,{1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0}
									,{1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1}
									,{1,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1}
									,{1,0,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,0,1}
									,{1,0,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,0,1}
									,{1,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,1}
									,{1,1,1,0,1,1,0,1,1,0,1,1,1,1,1,1,1,1,0,1,1,0,1,1,0,1,1,1}
									,{1,1,1,0,1,1,0,1,1,0,1,1,1,1,1,1,1,1,0,1,1,0,1,1,0,1,1,1}
									,{1,0,0,0,0,0,0,1,1,0,0,0,0,1,1,0,0,0,0,1,1,0,0,0,0,0,0,1}
									,{1,0,1,1,1,1,1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1,1,1,1,1,0,1}
									,{1,0,1,1,1,1,1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1,1,1,1,1,0,1}
									,{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1}
									,{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}
		};
}

public void move()
{
    
    if(move_dir==4){
        if(x==0&&y==14) pos_x=16*26;
    }
    
    if(move_dir==6){
        if(x==26&&y==14) pos_x=16*1;
    }
    
    if(pos_x%16==0) x=(int)(pos_x/16);
    if(pos_y%16==0) y=(int)(pos_y/16);
    
    if(pos_x%16==0&&pos_y%16==0){
    
    
    if(collision_map[y][x-1]==0) able_left=true; else able_left=false;
    if(collision_map[y][x+1]==0) able_right=true; else able_right=false;
    if(collision_map[y-1][x]==0) able_up=true; else able_up=false;
    if(collision_map[y+1][x]==0) able_down=true; else able_down=false;
    
    if(next_move_dir==4){
        if(collision_map[y][x-1]==0) move_dir=4;
    }
    
    if(next_move_dir==6){
        if(collision_map[y][x+1]==0) move_dir=6;
    }
    
    if(next_move_dir==2){
        if(collision_map[y+1][x]==0) move_dir=2;
    }
    
    if(next_move_dir==8){
        if(collision_map[y-1][x]==0) move_dir=8;
    }
    
    }
 if(move_dir==4)
 {
    if(collision_map[y][x-1]==0) pos_x=pos_x-1;
 }
 
 if(move_dir==6)
 {
    if(collision_map[y][x+1]==0) pos_x=pos_x+1;
 }
 
 if(move_dir==2)
 {
    if(collision_map[y+1][x]==0) pos_y=pos_y+1;
 }
 
 if(move_dir==8)
 {
    if(collision_map[y-1][x]==0) pos_y=pos_y-1;
 }
 
 
 //System.out.println("posx="+pos_x+" posy="+pos_y);
 //System.out.println("x="+(int)(pos_x/16)+" y="+(int)(pos_y/16));
}

public void set_frame()
{
    l++;
    
    if(l==4) l=-1;
    
    if(move_dir==4){
        if(l==0) current_frame=0;
        if(l==1) current_frame=6;
        if(l==2) current_frame=7;
        if(l==3) current_frame=6;
    }
    
    if(move_dir==6){
        if(l==0) current_frame=0;
        if(l==1) current_frame=8;
        if(l==2) current_frame=9;
        if(l==3) current_frame=8;
    }
    
    if(move_dir==2){
        if(l==0) current_frame=0;
        if(l==1) current_frame=4;
        if(l==2) current_frame=5;
        if(l==3) current_frame=4;
    }
    
    if(move_dir==8){
        if(l==0) current_frame=0;
        if(l==1) current_frame=2;
        if(l==2) current_frame=3;
        if(l==3) current_frame=2;
    }
    
}

}
